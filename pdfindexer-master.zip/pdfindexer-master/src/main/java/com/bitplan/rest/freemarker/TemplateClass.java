/**
 * Copyright (C) 2012 BITPlan GmbH
 *
 * Pater-Delp-Str. 1
 * D-47877 Willich-Schiefbahn
 *
 * http://www.bitplan.com
 * 
 */
package com.bitplan.rest.freemarker;

// wrapper for a template class
public class TemplateClass {
	@SuppressWarnings("rawtypes")
	Class clazz;
	String path;
}